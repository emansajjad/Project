package com.example.my_fyp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
